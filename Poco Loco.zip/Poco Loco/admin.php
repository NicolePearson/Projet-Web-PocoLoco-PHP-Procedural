<?php
//On démarre la session.
session_start();

//Point de connexion à la base de données.
include("connexion.php");
$connexion = connexionBd();

//Création d'une variable qui permettra d'afficher un message selon la condition.
$message = "";

//Permet d'éviter l'accès à la page d'administration sans s'avoir identifié.
if($_SESSION["login"] == false){
    header('Location: compte.php');
    exit;
}

//Requête qui récupère les catégories.
$requete_categorie = "SELECT * FROM categorie";
//Envoie de la requête.
$envoie_requete = $connexion->query($requete_categorie);
//On récupère les données.
$categories = $envoie_requete->fetchAll(PDO::FETCH_OBJ);


//Ajout à la base de données.
if(isset($_POST["submit-db"])){

    if(isset($_POST['designation']) && isset($_POST['description']) && isset($_FILES['image']) && isset($_POST['categorie']) && isset($_POST['prix']) && isset($_POST['tva'])){
        //On définit toute les variables avec le contenu rentrer dans le formulaire.
        $designation = $_POST['designation'];
        $description = $_POST['description'];
        $image = "images/". $_FILES["image"]["name"];
        $cat = $_POST['categorie'];
        $prix = $_POST['prix'];
        $tva = $_POST['tva'];

        if(!empty($_POST['designation']) && !empty($_POST['description']) && !empty($_FILES['image']) && !empty($_POST['categorie']) && !empty($_POST['prix']) && !empty($_POST['tva'])){
            //Si toute les cases du formulaire ont été rempli alors on prépare l'insertion du nouveau plat dans la base de données avec une requête préparéé.
            $requete_preparee = $connexion->prepare("INSERT INTO repas(id_repas, id_cat, designation, prix, tva, description, img) VALUES (NULL, :categorie , :designation , :prix, :tva, :description, :image)");
            $requete_preparee->bindParam(":categorie", $cat, PDO::PARAM_INT);
            $requete_preparee->bindParam(":designation", $designation);
            $requete_preparee->bindParam(":prix", $prix);
            $requete_preparee->bindParam(":tva", $tva);
            $requete_preparee->bindParam(":description", $description);
            $requete_preparee->bindParam(":image", $image);
            move_uploaded_file($_FILES["image"]["tmp_name"],$image);

            //Avant l'insertion on va vérifier que le plat n'existe pas déjà dans la base de données pour éviter les doublons.
            $requete_doublon = $connexion->prepare("SELECT designation FROM repas WHERE designation = :des");
            $requete_doublon->bindParam(":des", $designation);
            $send = $requete_doublon->execute();
            $requete_doublon_resultat = $requete_doublon->fetchAll(PDO::FETCH_ASSOC);

            //Message d'erreur si le plat existe déjà.
            if( !empty($requete_doublon_resultat) ){
                $message = "Error, this product already exists in your database.";
            }
            else{
                //Sinon exécution de la requête.
                $envoie = $requete_preparee->execute();
                $message = "Success, the product was added correctly to your database.";
            }
        }
        else{
            $message = "Error, the product was not added to your database.";
        }
    }
}

//Supprimer de la base de données.
if(isset($_POST["submit-remove"])){

    if(isset($_POST["designation_remove"])){
        //On définit une variable avec le contenu du formulaire.
        $designation_remove = $_POST["designation_remove"];

        if(!empty($_POST["designation_remove"])){
            $requete_preparee_2 = $connexion->prepare("SELECT designation FROM repas WHERE designation = :des_remove ");
            $requete_preparee_2->bindParam(":des_remove", $designation_remove);
            $send_2 = $requete_preparee_2->execute();
            $resultat_2 = $requete_preparee_2->fetchAll(PDO::FETCH_ASSOC);

            if( !empty($resultat_2) ){
            //Si le formumlaire a bien été rempli on supprime le plat dans la base de données grâce à une requête préparée.
                $requete_preparee_3 = $connexion->prepare("DELETE FROM repas WHERE designation = :designation_remove");
                $requete_preparee_3->bindParam(":designation_remove", $designation_remove, PDO::PARAM_STR);
                $send_3 = $requete_preparee_3->execute();

                $message = "The product was successfully removed from your database.";
            }
            else{
            //Si le plat n'existe pas dans la base de données aucune suppression sera faite et l'admin sera averti.
                $message = "Error, this product does not exist in your database.";
            }
        }
        else{
            $message = "Error, please fill out the field.";
        }
    }
}

//Récupération de toute la table 'repas' pour que l'admin puisse visualiser sa table sur le site.
//Requête qui récupère la totalité de la table repas.
$requete_repas = "SELECT * FROM repas";
//Envoie de la requête.
$envoie_requete_repas = $connexion->query($requete_repas);
//On récupère les données.
$repas = $envoie_requete_repas->fetchAll(PDO::FETCH_OBJ);

?>
<!doctype html>
<html lang="fr">
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">

    <!-- Site Metas -->
    <title>Poco Loco Restaurant</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- color -->
    <link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css"/>

    <!-- Modernizer -->
    <script src="js/modernizer.js"></script>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div id="site-header">
    <header id="header" class="header-block-top">
        <div class="container">
            <div class="row">
                <div class="main-menu">
                    <!-- navbar -->
                    <nav class="navbar navbar-default" id="mainNav">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="logo">
                                <a class="navbar-brand js-scroll-trigger logo-header" href="index.php">
                                    <img src="images/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="categorie.php?cat=all">Menus</a></li>
                                <li><a href="categorie.php?cat=1">Starters</a></li>
                                <li><a href="categorie.php?cat=2">Main courses</a></li>
                                <li><a href="categorie.php?cat=3">Desserts</a></li>
                                <li><a href="categorie.php?cat=4">Drinks</a></li>
                                <li><a href="commande.php">Order</a></li>
                                <!-- Le menu change en fonction du statut de l'utilisateur et si il est connecté ou non -->
                                <?php if($_SESSION["login"]== true) : ?>
                                    <!-- Si l'utilisateur est connecté il ne verra plus 'account' mais 'log out' pour pouvoir se déconnecter -->
                                    <li><a href="logout.php">Log out</a></li>
                                <?php else : ?>
                                    <!-- Sinon l'utlisateur aura la possiblité de se connecter. -->
                                    <li><a href="compte.php">Account</a></li>
                                <?php endif; ?>
                                <?php if($_SESSION["login"] == true && $_SESSION['statut'] == "admin") : ?>
                                    <!-- Si l'utilisateur est connecté et a le statut 'admin' alors il verra apparaître un onglet 'administration' dans le menu -->
                                    <li><a href="admin.php">Administration</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <!-- end nav-collapse -->
                    </nav>
                    <!-- end navbar -->
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </header>
    <!-- end header -->
</div>
<main>
<div class="team-main pad-top-100 pad-bottom-100 parallax">
    <h2 class="admin-title text-center margin">Administration</h2>
    <div class="login-page">
        <div class="form">
            <p><?php echo $message ?></p>
            <!-- Formulaire permettant de supprimer de la base de données -->
            <form class="register-form" method="post">
                <input type="text" name="designation_remove" placeholder="Product name"/>
                <input type="submit" name="submit-remove" value="Remove from database">
                <p class="message"><a href="#">Add product</a></p>
            </form>
            <!-- Formulaire permettant d'ajouter à la base de données -->
            <form name="form-login" class="login-form" method="post" enctype="multipart/form-data">
                <input type="text" name="designation" placeholder="Product name"/>
                <input type="text" name="description" placeholder="Description"/>
                <input type="file" name="image" accept="image/jpeg"/>
                <select name="categorie">
                    <?php foreach ($categories as $value) : ?>
                        <option value="<?=$value->id_cat?>"><?=$value->nom ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="number" name="prix" placeholder="Price without tax"/>
                <input type="number" name="tva" placeholder="Price with tax"/>
                <input type="submit" name="submit-db" value="add to database">
                <p class="message"><a href="#">Remove product</a></p>
            </form>
        </div>
    </div>
    <h2 class="admin-title text-center margin"> Your database: </h2>
    <div style="overflow-x:auto;">
    <table class="mytable">
        <tr>
            <th>id_repas</th>
            <th>id_categorie</th>
            <th>designation</th>
            <th>prix</th>
            <th>tva</th>
            <th>description</th>
            <th>image</th>
        </tr>
        <?php foreach($repas as $valeur) : ?>
        <tr>
            <td><?=$valeur->id_repas ?></td>
            <td><?=$valeur->id_cat ?></td>
            <td><?=$valeur->designation ?></td>
            <td><?=$valeur->prix ?></td>
            <td><?=$valeur->tva ?></td>
            <td><?=$valeur->description ?></td>
            <td><?=$valeur->img?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
</div>
</main>
<?php include("footer.php"); ?>
<!-- ALL JS FILES -->
<script src="js/all.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/custom.js"></script>
</body>
</html>
