<?php
//On démarre la session.
session_start();

//Point de connexion à la base de données.
include('connexion.php');
//Appel de la fonction connexionBd se trouvant dans le fichier connexion.php.
$connexion = connexionBd();

if (!empty($_GET['cat'])) {
    //On récupère la valeur de la variable passée via l'URL.
    $numCat = $_GET['cat'];
    //Requête préparée qui récupère les articles selon leur catégorie.
    $prepare = $connexion->prepare("SELECT * FROM repas WHERE id_cat = :numCat");
    //On défini la valeur du paramètre de la requête préparée.
    $prepare->bindParam(':numCat', $numCat);
    //Exécution de la requête préparée.
    $prepare->execute();
    //On récupère les données pour ensuite les affichées sur la page.
    $res = $prepare->fetchAll(PDO::FETCH_OBJ);

    //requête préparée permettant de récupérer toute les catégories
    $prepare_1 = $connexion->prepare("SELECT * FROM categorie WHERE id_cat = :numCat");
    //On défini la valeur du paramètre de la requête préparée.
    $prepare_1->bindParam(':numCat', $numCat);
    //Exécution de la requête préparée.
    $prepare_1->execute();
    //On récupère les données pour ensuite les affichées sur la page.
    $result = $prepare_1->fetchAll(PDO::FETCH_OBJ);

    if ($_GET['cat'] == 'all') {
        $requete_1 = "SELECT * FROM repas";
        //Envoie de la requête.
        $envoie_1 = $connexion->query($requete_1);
        //On récupère les données.
        $res = $envoie_1->fetchAll(PDO::FETCH_OBJ);
    }
} else {
    echo '<meta http-equiv="refresh" content="0;URL=index.php">';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">

    <!-- Site Metas -->
    <title>Poco Loco Restaurant</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- color -->
    <link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css"/>

    <!-- Modernizer -->
    <script src="js/modernizer.js"></script>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<div id="site-header">
    <header id="header" class="header-block-top">
        <div class="container">
            <div class="row">
                <div class="main-menu">
                    <!-- navbar -->
                    <nav class="navbar navbar-default" id="mainNav">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="logo">
                                <a class="navbar-brand js-scroll-trigger logo-header" href="index.php">
                                    <img src="images/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="categorie.php?cat=all">Menus</a></li>
                                <li><a href="categorie.php?cat=1">Starters</a></li>
                                <li><a href="categorie.php?cat=2">Main courses</a></li>
                                <li><a href="categorie.php?cat=3">Desserts</a></li>
                                <li><a href="categorie.php?cat=4">Drinks</a></li>
                                <li><a href="commande.php">Order</a></li>
                                <!-- Le menu change en fonction du statut de l'utilisateur et si il est connecté ou non -->
                                <?php if($_SESSION["login"]== true) : ?>
                                    <!-- Si l'utilisateur est connecté il ne verra plus 'account' mais 'log out' pour pouvoir se déconnecter -->
                                    <li><a href="logout.php">Log out</a></li>
                                <?php else : ?>
                                    <!-- Sinon l'utlisateur aura la possiblité de se connecter. -->
                                    <li><a href="compte.php">Account</a></li>
                                <?php endif; ?>
                                <?php if($_SESSION["login"] == true && $_SESSION['statut'] == "admin") : ?>
                                    <!-- Si l'utilisateur est connecté et a le statut 'admin' alors il verra apparaître un onglet 'administration' dans le menu -->
                                    <li><a href="admin.php">Administration</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <!-- end nav-collapse -->
                    </nav>
                    <!-- end navbar -->
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </header>
    <!-- end header -->
</div>
<main>
    <div id="our_team" class="team-main pad-top-100 pad-bottom-100 parallax">
        <div class="container">
            <div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.1s">
                <?php foreach ($result as $nomCat) : ?>
                    <?php if ($_GET['cat'] == 'all') : ?>
                        <h2 class="block-title text-center">Menus</h2>
                    <?php else : ?>
                        <h2 class="block-title text-center"><?=$nomCat->nom ?></h2>
                    <?php endif; ?>
                <?php endforeach; ?>
                <p class="title-caption text-center">There are many variations of passages of Lorem Ipsum available, but
                    the majority have suffered alteration in some form, by injected humour, or randomised words which
                    don't look even slightly believable. </p>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="team-box">
                        <div class="row">
                            <?php foreach ($res as $prod) : ?>
                                <div class="col-md-6 col-sm-6 space">
                                    <div class="sf-team">
                                        <div class="thumb">
                                            <a href="vue_produit.php?repas=<?= $prod->id_repas ?>"><img
                                                        src="<?= $prod->img ?>" alt=""></a>
                                        </div>
                                        <div class="text-col">
                                            <a href="vue_produit.php?repas=<?= $prod->id_repas ?>">
                                                <h3><?= $prod->designation ?></h3></a>
                                            <p><?= $prod->description ?></p>
                                            <ul class="team-social">
                                                <li><?= $prod->tva ?> $</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end team-box -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end team-main -->
</main>
<?php include("footer.php"); ?>
<!-- ALL JS FILES -->
<script src="js/all.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/custom.js"></script>
</body>