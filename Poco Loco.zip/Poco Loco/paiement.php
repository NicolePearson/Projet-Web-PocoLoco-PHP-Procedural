<?php
//On démarre la session.
session_start();

//Point de connexion à la base de données.
include("connexion.php");
$connexion = connexionBd();

$products = array();
$prixTotal = 0;
$message = "";

foreach ($_SESSION["order"] as $key => $repas) {

    //On récupère la valeur de la variable passée via l'URL.
    $numRepas = $repas['id_repas'];
    //Requête préparée qui récupère le repas selon son identifiant.
    $requete_preparee = $connexion->prepare("SELECT * FROM repas WHERE id_repas = :numRepas");
    //On défini la valeur du paramètre de la requête préparée.
    $requete_preparee->bindParam(':numRepas', $numRepas, PDO::PARAM_INT);
    //Exécution de la requête préparée.
    $requete_preparee->execute();
    //On récupère les données pour ensuite les affichées sur la page.
    array_push($products, $requete_preparee->fetchAll(PDO::FETCH_OBJ));

}

if (empty($_SESSION["order"])) {

    echo '<meta http-equiv="refresh" content="0;URL=index.php">';
}

if(isset($_POST["payer"])){
    foreach($_SESSION["order"] as $key=>$repas){
        //On récupère les valeurs dans la session de commande.
        $id_repas = $repas['id_repas'];
        $qte_repas = $repas['nbProduits'];

        //Requête préparée d'insertion
        $requete_preparee_2 = $connexion->prepare("INSERT INTO ligne_commande VALUES(NULL, :id_repas, :qte_repas)");
        //On défini les valeurs du paramètre de la requête préparée.
        $requete_preparee_2->bindParam(':id_repas', $id_repas, PDO::PARAM_INT);
        $requete_preparee_2->bindParam(':qte_repas', $qte_repas, PDO::PARAM_INT);
    }
    //Exécution de la requête préparée.
    $requete_preparee_2->execute();

    $id = $_SESSION["id"];
    $prix = $_SESSION['prix'];

    $requete_preparee_3 = $connexion->prepare("INSERT INTO commande (id_commande, id_client, prix_total) VALUES(NULL, :id, :prix)");
    //On défini les valeurs du paramètre de la requête préparée.
    $requete_preparee_3->bindParam(':id', $id, PDO::PARAM_INT);
    $requete_preparee_3->bindParam(':prix', $prix);

    //Exécution de la requête préparée.
    $requete_preparee_3->execute();

    $message = "Payment successful, your food will be delivered shortly!";
}
?>
<!doctype html>
<html lang="fr">
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">

    <!-- Site Metas -->
    <title>Poco Loco Restaurant</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- color -->
    <link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css"/>

    <!-- Modernizer -->
    <script src="js/modernizer.js"></script>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<main>
    <div class="team-main pad-top-100 pad-bottom-100 parallax">
        <?php if (!empty($_SESSION["order"])) : ?>
            <div class="container">
                <h2 class="admin-title text-center margin"> Your Order Recapitulation: </h2>
                <div style="overflow-x:auto;">
                    <table id="cart" class="mytable">
                        <thead>
                        <tr>
                            <th style="width:50%">Product</th>
                            <th style="width:10%">Price</th>
                            <th style="width:8%">Quantity</th>
                            <th style="width:22%" class="text-center">Subtotal</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($products as $key => $repas) : ?>
                            <tr>
                                <td data-th="Product">

                                    <div class="row">
                                        <div class="col-sm-2 hidden-xs"><img src="<?= $repas[0]->img ?>" alt="..."
                                                                             class="img-responsive"/></div>
                                        <div class="col-sm-10">

                                            <h4 class="nomargin"><?= $repas[0]->designation ?></h4>

                                            <p><?= $repas[0]->description ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td data-th="Price"><?= $repas[0]->tva ?>$</td>
                                <td data-th="Quantity">
                                    <input type="number" class="form-control text-center" value="<?= $_SESSION["order"][$repas[0]->designation]["nbProduits"] ?>">
                                </td>
                                <td data-th="Subtotal" class="text-center">
                                    <?= $_SESSION["order"][$repas[0]->designation]["nbProduits"] * $repas[0]->tva ?>
                                    $
                                </td>

                                <?php $prixTotal += $_SESSION["order"][$repas[0]->designation]["nbProduits"] * $repas[0]->tva ?>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td><a href="categorie.php?cat=all" class="btn btn-danger"><i class="fa fa-angle-left"></i>Continue Shopping</a>
                            </td>
                            <td colspan="2" class="hidden-xs"></td>
                            <td class="hidden-xs text-center"><strong>Total <?=$_SESSION['prix']  = $prixTotal ?>$</strong></td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        <?php endif; ?>
        <form class="text-center index" method="post" action="paiement.php">
            <input type="submit" value="Pay" name="payer">
        </form>
        <div class="admin-title index text-center">
            <p><?=$message?></p>
        </div>
    </div>
    <?php include("footer.php"); ?>
</main>
<!-- ALL JS FILES -->
<script src="js/all.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/custom.js"></script>
</body>
</html>