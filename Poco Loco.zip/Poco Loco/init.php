<?php
//Pour initialiser les variables de session essentielles au fonctionnement du site.
session_start();

if(!isset($_SESSION["statut"]))
    $_SESSION["statut"] = "";

if(!isset($_SESSION["login"]))
    $_SESSION["login"] = false;

if(!isset($_SESSION["order"]))
    $_SESSION["order"] = array();

if(!isset($_SESSION["id"]))
    $_SESSION["id"] = NULL;

if(!isset($_SESSION["prix"]))
    $_SESSION["prix"] = 0;

?>
