<?php
//On démarre la session.
session_start();

//Point de connexion à la base de données.
include("connexion.php");
$connexion = connexionBd();

//Suppression d'un article de la commande
if (isset($_POST["delete"])) {

    if(!empty($_POST["quantite"])){
        $quantite = $_POST["quantite"];
        $id_repas = $_POST["id_repas"];

        //Requête préparée permettant de mettre à jour la table repas, elle ajoute la quantité d'un plat retiré de la commande par un utilisateur.
        $requete_preparee_2 = $connexion->prepare("UPDATE repas SET quantite = quantite + :qte WHERE id_repas = :id");
        $requete_preparee_2->bindParam(':qte', $quantite,PDO::PARAM_INT);
        $requete_preparee_2->bindParam(':id', $id_repas,PDO::PARAM_INT);
        $requete_preparee_2->execute();
    }

    if (isset($_POST["id_repas"])) {

        $id = $_POST["id_repas"];
        $designation_repas = $_POST["designation_repas"];

    //On Parcourt la session et on retire le plat selon sa désignation
        foreach ($_SESSION["order"] as $key => $repas) {
            if ($key == $designation_repas) {
                unset($_SESSION["order"][$key]);
            }
        }
    }
}

//Initialisation de variables.
$products = array();
$prixTotal = 0;

foreach ($_SESSION["order"] as $key => $repas) {

    //On récupère la valeur de la variable passée via l'URL.
    $numRepas = $repas['id_repas'];
    //Requête préparée qui récupère le repas selon son identifiant.
    $requete_preparee = $connexion->prepare("SELECT * FROM repas WHERE id_repas = :numRepas");
    //On défini la valeur du paramètre de la requête préparée.
    $requete_preparee->bindParam(':numRepas', $numRepas, PDO::PARAM_INT);
    //Exécution de la requête préparée.
    $requete_preparee->execute();
    //Permet de rajouter dans le tableau 'products' le résultat de la requête préparée.
    array_push($products, $requete_preparee->fetchAll(PDO::FETCH_OBJ));

}

?>
<!doctype html>
<html lang="fr">
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">

    <!-- Site Metas -->
    <title>Poco Loco Restaurant</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- color -->
    <link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css"/>

    <!-- Modernizer -->
    <script src="js/modernizer.js"></script>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<div id="site-header">
    <header id="header" class="header-block-top">
        <div class="container">
            <div class="row">
                <div class="main-menu">
                    <!-- navbar -->
                    <nav class="navbar navbar-default" id="mainNav">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="logo">
                                <a class="navbar-brand js-scroll-trigger logo-header" href="index.php">
                                    <img src="images/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="categorie.php?cat=all">Menus</a></li>
                                <li><a href="categorie.php?cat=1">Starters</a></li>
                                <li><a href="categorie.php?cat=2">Main courses</a></li>
                                <li><a href="categorie.php?cat=3">Desserts</a></li>
                                <li><a href="categorie.php?cat=4">Drinks</a></li>
                                <li><a href="commande.php">Order</a></li>
                                <!-- Le menu change en fonction du statut de l'utilisateur et si il est connecté ou non -->
                                <?php if ($_SESSION["login"] == true) : ?>
                                    <!-- Si l'utilisateur est connecté il ne verra plus 'account' mais 'log out' pour pouvoir se déconnecter -->
                                    <li><a href="logout.php">Log out</a></li>
                                <?php else : ?>
                                    <!-- Sinon l'utlisateur aura la possiblité de se connecter. -->
                                    <li><a href="compte.php">Account</a></li>
                                <?php endif; ?>
                                <?php if ($_SESSION["login"] == true && $_SESSION['statut'] == "admin") : ?>
                                    <!-- Si l'utilisateur est connecté et a le statut 'admin' alors il verra apparaître un onglet 'administration' dans le menu -->
                                    <li><a href="admin.php">Administration</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <!-- end nav-collapse -->
                    </nav>
                    <!-- end navbar -->
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </header>
    <!-- end header -->
</div>
<!-- end site-header -->
<body>
<main>
    <div class="team-main pad-top-100 pad-bottom-100 parallax">
        <?php if (!empty($_SESSION["order"])) : ?>
            <div class="container">
                <h2 class="admin-title text-center margin"> Your Order: </h2>
                <div style="overflow-x:auto;">
                    <table id="cart" class="mytable">
                        <thead>
                        <tr>
                            <th style="width:50%">Product</th>
                            <th style="width:10%">Price</th>
                            <th style="width:8%">Quantity</th>
                            <th style="width:22%" class="text-center">Subtotal</th>
                            <th style="width:10%"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($products as $key => $repas) : ?>
                            <tr>
                                <td data-th="Product">
                                    <div class="row">
                                        <div class="col-sm-2 hidden-xs"><img src="<?= $repas[0]->img ?>" class="img-responsive"/></div>
                                        <div class="col-sm-10">
                                            <h4 class="nomargin"><?= $repas[0]->designation ?></h4>
                                            <p><?= $repas[0]->description ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td data-th="Price"><?= $repas[0]->tva ?>$</td>
                                <td data-th="Quantity">
                                    <input type="number" class="form-control text-center" value="<?= $_SESSION["order"][$repas[0]->designation]["nbProduits"] ?>">
                                </td>
                                <td data-th="Subtotal" class="text-center"><?= $_SESSION["order"][$repas[0]->designation]["nbProduits"] * $repas[0]->tva ?>$</td>
                                <td class="actions" data-th="">
                                    <form action="commande.php" method="post">
                                        <input type="hidden" name="id_repas" value="<?= $repas[0]->id_repas ?>">
                                        <input type="hidden" name="designation_repas" value="<?=$repas[0]->designation ?>">
                                        <input type="hidden" name="quantite" value="<?= $_SESSION["order"][$repas[0]->designation]["nbProduits"] ?>">
                                        <input type="submit" name="delete" value="Remove">
                                    </form>
                                </td>
                                <?php $prixTotal += $_SESSION["order"][$repas[0]->designation]["nbProduits"] * $repas[0]->tva ?>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                        <tfoot>

                        <tr>
                            <td><a href="categorie.php?cat=all" class="btn btn-danger"><i class="fa fa-angle-left"></i>
                                    Continue Shopping</a>
                            </td>
                            <td colspan="2" class="hidden-xs"></td>
                            <td class="hidden-xs text-center"><strong>Total <?= $prixTotal ?>$</strong></td>
                            <?php if ($_SESSION["login"] == false): ?>
                            <td><a href="#" class="btn btn-danger btn-block disabled">Checkout <i
                                            class="fa fa-angle-right"></i></a>
                                <a href="compte.php" class="btn btn-danger btn-xs">Please login first</a>
                                <?php else: ?>
                            <td><a href="paiement.php" class="btn btn-danger btn-block">Checkout <i class="fa fa-angle-right"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        <?php else: ?>
            <h2 class="admin-title text-center margin">You have no current order.</h2>
            <div class="text-center index">
                <a href="categorie.php?cat=all" class="btn btn-danger"><i class="fa fa-angle-left"></i> Continue
                    Shopping</a>
            </div>
        <?php endif; ?>
    </div>
    <?php include("footer.php"); ?>
</main>
<!-- ALL JS FILES -->
<script src="js/all.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/custom.js"></script>
</body>
</html>