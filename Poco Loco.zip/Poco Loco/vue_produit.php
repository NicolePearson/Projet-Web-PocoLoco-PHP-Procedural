<?php
//On démarre la session.
session_start();

//Point de connexion à la base de données.
include("connexion.php");
//Appel de la fonction connexionBd se trouvant dans le fichier connexion.php.
$connexion = connexionBd();

//Initialisation de variables
$tab = [];
$message = "";

if (!empty($_GET['repas'])) {
    //On récupère la valeur de la variable passée via l'URL.
    $numRepas = $_GET['repas'];
    //Requête préparée qui récupère le repas selon son identifiant.
    $requete_preparee = $connexion->prepare("SELECT * FROM repas WHERE id_repas = :numRepas");
    //On défini la valeur du paramètre de la requête préparée.
    $requete_preparee->bindParam(':numRepas', $numRepas, PDO::PARAM_INT);
    //Exécution de la requête préparée.
    $requete_preparee->execute();
    //On récupère les données pour ensuite les affichées sur la page.
    $tab = $requete_preparee->fetchAll(PDO::FETCH_OBJ);

} else {
    //redirection vers la page d'acceuil
    echo '<meta http-equiv="refresh" content="0;URL=index.php">';
}

//Ajout à la commande
if (isset($_POST["add"])) {

    if(isset($_POST["nbProduits"])){
        //On récupère les données du formulaire.
        $quantite = $_POST["nbProduits"];
        $id_repas = $_POST["id_repas"];

        //Requête préparée permettant de sélectionner la quantité du plat par rapport à son identifiant
        $requete_preparee_2 = $connexion->prepare("SELECT quantite FROM repas WHERE id_repas = :id");
        $requete_preparee_2->bindParam(':id', $id_repas);
        $requete_preparee_2->execute();
        //On récupère le résultat
        $resultat_2 = $requete_preparee_2->fetch(PDO::FETCH_ASSOC);

        //Requête préparée permettant de mettre à jour la table repas, elle soustrait la quantité d'un plat ajouté par un utilisateur.
        $requete_preparee_3 = $connexion->prepare("UPDATE repas SET quantite = quantite - :qte WHERE id_repas = :id");
        $requete_preparee_3->bindParam(':qte', $quantite,PDO::PARAM_INT);
        $requete_preparee_3->bindParam(':id', $id_repas,PDO::PARAM_INT);

        //On vérifie avant l'exécution de la requête qu'il reste une quantité suffisante.
        if($resultat_2["quantite"] >= $quantite) {
            //Exécution de la requête préparée
            $requete_preparee_3->execute();

            //Gestion de la session de commande de l'utilisateur
            if (isset($_SESSION["order"])) {

                $key = $_POST["designation_repas"];
                $id_repas = $_POST["id_repas"];

                $tab_repas_id = array_column($_SESSION["order"], "id_repas");;

                //Condition qui évite les doublons dans la commande.
                if (in_array($id_repas, $tab_repas_id)) {
                    //On ajoute pas le plat et on affiche un message pour l'utilisateur.
                    $message = "This dish has already been added to your order.";
                } else {
                    //Création d'un tableau qui contient l'id du repas ainsi que la quantité.
                    $tab_repas = array(
                        'id_repas' => $_POST["id_repas"],
                        'nbProduits' => $_POST["nbProduits"]
                    );
                    //On stock dans la session le tableau ci-dessus.
                    $_SESSION["order"][$key] = $tab_repas;
                }

            } else {

                $key = $_POST["designation_repas"];
                $id_repas = $_POST["id_repas"];

                $tab_repas = array(
                    'id_repas' => $_POST["id_repas"],
                    'nbProduits' => $_POST["nbProduits"]
                );

                $_SESSION["order"][$key] = $tab_repas;
            }
        }
    }

}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">

    <!-- Site Metas -->
    <title>Poco Loco Restaurant</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- color -->
    <link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css"/>

    <!-- Modernizer -->
    <script src="js/modernizer.js"></script>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<div id="site-header">
    <header id="header" class="header-block-top">
        <div class="container">
            <div class="row">
                <div class="main-menu">
                    <!-- navbar -->
                    <nav class="navbar navbar-default" id="mainNav">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="logo">
                                <a class="navbar-brand js-scroll-trigger logo-header" href="index.php">
                                    <img src="images/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="categorie.php?cat=all">Menus</a></li>
                                <li><a href="categorie.php?cat=1">Starters</a></li>
                                <li><a href="categorie.php?cat=2">Main courses</a></li>
                                <li><a href="categorie.php?cat=3">Desserts</a></li>
                                <li><a href="categorie.php?cat=4">Drinks</a></li>
                                <li><a href="commande.php">Order</a></li>
                                <!-- Le menu change en fonction du statut de l'utilisateur et si il est connecté ou non -->
                                <?php if ($_SESSION["login"] == true) : ?>
                                    <!-- Si l'utilisateur est connecté il ne verra plus 'account' mais 'log out' pour pouvoir se déconnecter -->
                                    <li><a href="logout.php">Log out</a></li>
                                <?php else : ?>
                                    <!-- Sinon l'utlisateur aura la possiblité de se connecter. -->
                                    <li><a href="compte.php">Account</a></li>
                                <?php endif; ?>
                                <?php if ($_SESSION["login"] == true && $_SESSION['statut'] == "admin") : ?>
                                    <!-- Si l'utilisateur est connecté et a le statut 'admin' alors il verra apparaître un onglet 'administration' dans le menu -->
                                    <li><a href="admin.php">Administration</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <!-- end nav-collapse -->
                    </nav>
                    <!-- end navbar -->
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </header>
    <!-- end header -->
</div>
<!-- end site-header -->
<body>
<main>
    <section class="team-main pad-top-100 pad-bottom-100 parallax">
        <div class="product">
            <?php foreach ($tab as $val) : ?>
                <header>
                    <h2 class="product"><?= $val->designation ?></h2>
                </header>
                <article class="flex">
                    <img class="border" src="<?= $val->img ?>">
                    <article class="flex2">
                        <p><?= $val->description ?></p>
                        <p><?= $val->tva ?> $</p>
                        <form action="vue_produit.php?repas=<?= $val->id_repas ?>" method="post">
                            <label for="nbProduits">Quantity:
                                <input type="number" name="nbProduits" min="1" max="10" value="1" placeholder="1">
                            </label>
                            <input type="hidden" name="id_repas" value="<?= $val->id_repas ?>">
                            <input type="hidden" name="designation_repas" value="<?= $val->designation ?>">
                            <input type="submit" name="add" value="Add to your order">
                        </form>
                        <p><?= $message ?></p>
                    </article>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

</main>
<?php include("footer.php"); ?>
<!-- ALL JS FILES -->
<script src="js/all.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/custom.js"></script>
</body>
