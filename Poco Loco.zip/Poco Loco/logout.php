<?php
//Cette page sert à bien effacer toute les variables de session créé lors de la connexion de l'utilisateur.

// On démarre la session
session_start ();

unset($_SESSION["login"]);
$_SESSION["order"] = array();

unset($_SESSION['id']);

unset($_SESSION['prix']);

// On détruit les variables de notre session
//session_unset ();

// On détruit notre session
//session_destroy ();

// On redirige le visiteur vers la page de connexion
header('Location: compte.php');
exit;

?>