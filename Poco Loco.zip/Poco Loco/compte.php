<?php
//On démarre la session.
session_start();

//Point de connexion à la base de données.
include ("connexion.php");
$connexion = connexionBd();

//On créé la clé login si elle n'existe pas.
//La clé login sert à savoir si un utilisateur est connecté ou non.
if( !isset($_SESSION["login"]) ){
    $_SESSION["login"] = false;
}

//Création d'une variable qui permettra d'afficher un message selon la condition.
$message = "";

//Création d'un compte.
if(isset($_POST["submit-account"])){
    if(isset($_POST["prenom"]) && isset($_POST["nom"]) && isset($_POST["mail"]) && isset($_POST["addresse"]) && isset($_POST["ville"]) && isset($_POST["cp"]) && isset($_POST["tel"]) && isset($_POST["mdp"])){

        //On définit toute les variables avec le contenu rentrer dans le formulaire.
        $prenom = htmlspecialchars(addslashes($_POST["prenom"]));
        $nom = htmlspecialchars(addslashes($_POST["nom"]));
        $mail = htmlspecialchars(addslashes($_POST["mail"]));
        $addresse = htmlspecialchars(addslashes($_POST["addresse"]));
        $ville = htmlspecialchars($_POST["ville"]);
        $cp = htmlspecialchars($_POST["cp"]);
        $tel = htmlspecialchars($_POST["tel"]);
        //On hash le mot de passe rentrer dans le formulaire.
        $password_hash = password_hash($_POST["mdp"], PASSWORD_DEFAULT);

        //Vérifie dans le mot de passe si il y a une lettre majuscule et un nombre.
        $uppercase = preg_match('@[A-Z]@', htmlspecialchars($_POST['mdp']));
        $number = preg_match('@[0-9]@', htmlspecialchars($_POST['mdp']));

        //On vérifie si le compte n'existe pas déjà dans la base de données.
       $requete_preparee_1= $connexion->prepare("SELECT email FROM client WHERE email = :mail");
        $requete_preparee_1->bindParam(':mail',$mail);
        $requete_preparee_1->execute();
        $resultat_1  = $requete_preparee_1->fetch(PDO::FETCH_ASSOC);

        if(!empty($resultat_1)){
            $message = "This account already exists.";
        }
        else {
            //On prépare l'insertion du nouveau compte grâce à une requête préparée.
            $requete_preparee_2 = $connexion->prepare("INSERT INTO client(id_client, email, mdp, nom, prenom, adresse, cp, ville, telephone) VALUES (NULL, :email, :password, :lastName, :firstName, :adress, :code, :city, :phone )");
            $requete_preparee_2->bindParam(":email", $mail);
            $requete_preparee_2->bindParam(":password", $password_hash);
            $requete_preparee_2->bindParam(":lastName", $nom);
            $requete_preparee_2->bindParam(":firstName", $prenom);
            $requete_preparee_2->bindParam(":adress", $addresse);
            $requete_preparee_2->bindParam(":code", $cp, PDO::PARAM_INT);
            $requete_preparee_2->bindParam(":city", $ville);
            $requete_preparee_2->bindParam(":phone", $tel, PDO::PARAM_INT);

            //Création des variables de session permettant de récupérer le nom et prénom du nouveau utilisateur.
            $_SESSION["nom"] = $nom;
            $_SESSION["prenom"] = $prenom;

            //Si le mot de passe de contient pas au moins une majuscule, un chiffre et a une longueur minimum de 8 caractères alors le compte n'aboutira pas.
            if (!$uppercase || !$number || strlen(htmlspecialchars($_POST['mdp'])) < 8) {
                $message = 'Password should be at least 8 characters in length and should include at least one upper case letter and one number.';
            } else {
                //Dans le cas où tout est bon on insère le nouveau compte dans la base de données.
                $resultat_2 = $requete_preparee_2->execute();
                //Le nouveau utilisateur est acceuilli avec un message personnalisé et devra se connecter au site.
                $message = "Account successfully created! Welcome ". $_SESSION["prenom"] . " " . $_SESSION["nom"] . " please login.";

            }

        }
    }
}

//var_dump(password_hash('Admin1234', PASSWORD_DEFAULT));
//var_dump(password_hash('User1234', PASSWORD_DEFAULT));

//Login
if(isset($_POST["user"]) && isset($_POST["pwd"]) && isset($_POST["submit-login"]) && isset($_POST['id'])){
    //On définit la variable pour récupérer le contenu du formulaire.
    $user = htmlspecialchars(addslashes($_POST['user']));

    //On vérifie si l'utilisateur a déjà un compte sur le site en recherchant son adresse mail dans la base de données.
    $requete_preparee= $connexion->prepare("SELECT id_client, nom, prenom, email, mdp, statut FROM client WHERE email = :mail");
    $requete_preparee->bindParam(':mail',$user);
    $requete_preparee->execute();

    $resultat  = $requete_preparee->fetch(PDO::FETCH_ASSOC);

    //Si on a bien retrouvé l'utilisateur dans la base de données on vérifie si les mots de passes correspondent.
    if(is_array($resultat)){
        if(password_verify(htmlspecialchars($_POST["pwd"]),$resultat['mdp'])){
            //Si les mots de passes se correspondent on considère l'utilisateur comme connecté.
            //On change la variable de session pour se souvenir que l'utilisateur est connecté.
            $_SESSION["login"] = true;
            //On récupère aussi le statut de l'utilisateur pour se rappeler si il est admin on client.
            $_SESSION['statut'] = $resultat['statut'];
            //On récupère l'id du client
            $_SESSION["id"] = $resultat['id_client'];
        }
        else{
            $message =  "Your email address or password is incorrect, please try again.";
        }
    }
    else{
        echo "Error!";
    }
}

//Si l'utilisateur est déjà connecté sur le site on le redirige vers la page index.
//Si l'utilisateur est admin il est redirigé vers la page d'administration.
if( $_SESSION["login"] == true ){
    if($resultat['statut'] == 'admin'){
        header('Location: admin.php');
        exit;
    }
    else{
        header('Location: categorie.php?cat=all');
        exit;
    }
}

?>
<!doctype html>
<html lang="fr">
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">

    <!-- Site Metas -->
    <title>Poco Loco Restaurant</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- color -->
    <link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css"/>

    <!-- Modernizer -->
    <script src="js/modernizer.js"></script>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div id="site-header">
    <header id="header" class="header-block-top">
        <div class="container">
            <div class="row">
                <div class="main-menu">
                    <!-- navbar -->
                    <nav class="navbar navbar-default" id="mainNav">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="logo">
                                <a class="navbar-brand js-scroll-trigger logo-header" href="index.php">
                                    <img src="images/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="categorie.php?cat=all">Menus</a></li>
                                <li><a href="categorie.php?cat=1">Starters</a></li>
                                <li><a href="categorie.php?cat=2">Main courses</a></li>
                                <li><a href="categorie.php?cat=3">Desserts</a></li>
                                <li><a href="categorie.php?cat=4">Drinks</a></li>
                                <li><a href="commande.php">Order</a></li>
                                <!-- Le menu change en fonction du statut de l'utilisateur et si il est connecté ou non -->
                                <?php if($_SESSION["login"]== true) : ?>
                                <!-- Si l'utilisateur est connecté il ne verra plus 'account' mais 'log out' pour pouvoir se déconnecter -->
                                    <li><a href="logout.php">Log out</a></li>
                                <?php else : ?>
                                <!-- Sinon l'utlisateur aura la possiblité de se connecter. -->
                                    <li><a href="compte.php">Account</a></li>
                                <?php endif; ?>
                                <?php if($_SESSION["login"] == true && $_SESSION['statut'] == "admin") : ?>
                                <!-- Si l'utilisateur est connecté et a le statut 'admin' alors il verra apparaître un onglet 'administration' dans le menu -->
                                    <li><a href="admin.php">Administration</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <!-- end nav-collapse -->
                    </nav>
                    <!-- end navbar -->
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </header>
    <!-- end header -->
</div>
<main>
    <div class="team-main pad-top-100 pad-bottom-100 parallax">
    <h2 class="admin-title text-center margin">Welcome! Hope you're hungry...</h2>
    <div class="login-page">
        <div class="form">
            <!-- Créer un compte -->
            <form class="register-form" action="compte.php" method="post">
                <input type="text" placeholder="Firstname" name="prenom"/>
                <input type="text" placeholder="Lastname" name="nom"/>
                <input type="text" placeholder="Email address" name="mail"/>
                <input type="text" placeholder="Street address" name="addresse"/>
                <input type="text" placeholder="City" name="ville"/>
                <input type="number" placeholder="Post code" name="cp"/>
                <input type="number" placeholder="Phone number" name="tel"/>
                <p class="message">At least 8 characters, one uppercase and one number required for your password:</p><br>
                <input type="password" placeholder="Password" name="mdp"/>
                <input type="submit" name="submit-account" value="create account">
                <p class="message">Already registered? <a href="#">Sign In</a></p>
            </form>
            <!-- Se connecter -->
            <form name="form-login" class="login-form" method="post">
                <input type="email" placeholder="Email" name="user"/>
                <input type="password" placeholder="Password" name="pwd"/>
                <input type="submit" name="submit-login" value="login">
                <input type="hidden" name="id">
                <p class="message">Not registered? <a href="#">Create an account</a></p>
            </form>
            <p><?php echo $message?></p>
        </div>
    </div>
    </div>
    <?php include("footer.php"); ?>
</main>
<!-- ALL JS FILES -->
<script src="js/all.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/custom.js"></script>
</body>
</html>
